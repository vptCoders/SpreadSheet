<?php 
	session_start();
?>
<div class="lff--login_card" style="margin-top: 100px">
	<div class="login_main">
		<span style="display: block; font-family: Cordia New; font-size: 30px; margin-left: auto; margin-right: auto; width: 55%; text-align: center; margin-top: 30px; margin-bottom: 80px; word-wrap: break-word; line-height: 1em; user-select: none;">Coloque o seu dedo sobre o leitor biométrico</span>
		<div class="lff--icon_fingerprint"></div>
		<button class="lff--button_flat" id="login_password_btn">Fazer login com credenciais</button>
		<div class="fingerprint_reading_error_warning" style="margin-top: 20px">A minha impressão digital não é reconhecida</div>
	</div>
</div>

<style>
	button#login_password_btn {
		display: block; 
		margin-left: auto; 
		margin-right: auto; 
		margin-top: 110px; 
		width: 230px; 
		height: 50px
	}
</style>