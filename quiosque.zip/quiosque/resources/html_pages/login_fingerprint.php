<?php 
	session_start();
?>

<style>
	div.lff--login_card {
		margin-top: 100px;
	}

	div#login_fingerprint_card {
		background-color: white;
		position: absolute;
		top: 0;
		left: 0;
		transition: left .5s cubic-bezier(0,0,.2,1);
		z-index: 1;
	}

	div#login_password_card {
		background-color: white;
		position: absolute;
		top: 0;
		left: 400px;
		transition: left .5s cubic-bezier(0,0,.2,1);
		z-index: 2;
	}

	button#login_password_btn {
		display: block; 
		margin-left: auto; 
		margin-right: auto; 
		margin-top: 110px; 
		width: 230px; 
		height: 50px;
	}

	button#login_fingerprint_btn {
		display: block; 
		margin-left: auto; 
		margin-right: auto; 
		margin-top: 110px; 
		width: 260px; 
		height: 50px;
	}

	span.lff--label_h1 {
		width: 55%; 
		margin-top: 30px; 
		margin-bottom: 80px; 
	}

	span#login_password_label {
		width: 60%;
	}

	span.lff--label_h4 {
		margin-top: 20px;
	}
</style>

<div class="lff--login_card">
	<div class="lff--login_card_body" id="login_fingerprint_card">
		<span class="lff--label_h1">Coloque o seu dedo sobre o leitor biométrico</span>
		<div class="lff--icon_fingerprint"></div>
		<button class="lff--button_flat" id="login_password_btn">Fazer login com credenciais</button>
		<span class="lff--label_h4">A minha impressão digital não é reconhecida</span>
	</div>

	<div class="lff--login_card_body" id="login_password_card">
		<span class="lff--label_h1" id="login_password_label">Introduza o seu nome de utilizador e palavra-passe</span>
		<form>
			<input type="text" name="F">
			<input type="password" name="">
		</form>
		<button class="lff--button_flat" id="login_fingerprint_btn">Fazer login com impressão digital</button>
		<span class="lff--label_h4">As minhas credenciais não são reconhecidas</span>
	</div>
</div>

<script type="text/javascript">
	let buttonPassword = document.getElementById("login_password_btn");
	let buttonFingerprint = document.getElementById("login_fingerprint_btn");

	let fingerprintCard = document.getElementById("login_fingerprint_card");
	let credentialsCard = document.getElementById("login_password_card");

	buttonPassword.addEventListener("click", function(evt) {
		credentialsCard.style.zIndex = "2";
		fingerprintCard.style.zIndex = "1";
		credentialsCard.style.left = "0px";

		setTimeout(function(evt) {
			fingerprintCard.style.left = "400px";
		}, 500);
	});

	buttonFingerprint.addEventListener("click", function(evt) {
		credentialsCard.style.zIndex = "1";
		fingerprintCard.style.zIndex = "2";
		fingerprintCard.style.left = "0px";

		setTimeout(function(evt) {
			credentialsCard.style.left = "400px";
		}, 500);
	});
</script>