"use strict";

function VirtualKeyboard() {
	let capsActive = false;
	let shiftActive = false;
	let printTilde = false;
	let printPower = false;

	let KEYBOARD = "lff--keyboard";
	let CONTAINER = "container";
	let ACTIVE = "active";
	let VISIBLE = "visible";

	let KEYBOARD_STYLE_V1 = "lff--keyboard_style_v1";
	let KEYBOARD_KEY_ROW_CONTAINER = "lff--keyboard_key_row_container";
	let KEYBOARD_KEY = "lff--keyboard_key";
	let KEYBOARD_KEY_PRIMARY = "lff--keyboard_key_primary";
	let KEYBOARD_KEY_SECONDARY = "lff--keyboard_key_secondary";
	let KEYBOARD_KEY_NUMERIC = "lff--keyboard_key_numeric";
	let KEYBOARD_KEY_LETTER = "lff--keyboard_key_letter";
	let KEYBOARD_KEY_SPECIAL = "lff--keyboard_key_special";
	let KEYBOARD_KEY_TAB = "lff--keyboard_key_tab";
	let KEYBOARD_KEY_CAPS = "lff--keyboard_key_caps";
	let KEYBOARD_KEY_BACKSPACE = "lff--keyboard_key_backspace";
	let KEYBOARD_KEY_LEFT_SHIFT = "lff--keyboard_key_left_shift";
	let KEYBOARD_KEY_RIGHT_SHIFT = "lff--keyboard_key_right_shift";
	let KEYBOARD_KEY_ENTER = "lff--keyboard_key_enter";
	let KEYBOARD_KEY_ARROW = "lff--keyboard_key_arrow";
	let KEYBOARD_KEY_SPACEBAR = "lff--keyboard_key_spacebar";

	let CURRENT_KEYBOARD = null;
	let TARGETS = [];

	function createKeyboard_v1() {
		let container = document.createElement("div");
		container.addEventListener("mousedown", function(evt) {
			evt.preventDefault();
		});
		container.classList.add(KEYBOARD);
		container.classList.add(CONTAINER);
		container.classList.add(KEYBOARD_STYLE_V1);
		let firstRow = createRow(container, ["\\", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "'", "«", "backspace"], KEYBOARD_STYLE_V1);
		let secondRow = createRow(container, ["tab", "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "+", "´"], KEYBOARD_STYLE_V1);
		let thirdRow = createRow(container, ["caps", "a", "s", "d", "f", "g", "h", "j", "k", "l", "ç", "º", "~"], KEYBOARD_STYLE_V1);
		let fourthRow = createRow(container, ["left_shift", "<", "z", "x", "c", "v", "b", "n", "m", ",", ".", "-", "up_arrow", "right_shift"], KEYBOARD_STYLE_V1);
		let fifthRow = createRow(container, ["alt_gr", "spacebar", "left_arrow", "down_arrow", "right_arrow", "delete"], KEYBOARD_STYLE_V1);
		let enterKey = createKey("enter", KEYBOARD_STYLE_V1);
		container.appendChild(firstRow);
		container.appendChild(secondRow);
		container.appendChild(thirdRow);
		container.appendChild(fourthRow);
		container.appendChild(fifthRow);
		container.appendChild(enterKey);
		document.body.appendChild(container);
		CURRENT_KEYBOARD = container;
	}

	function createRow(container, keys, keyboardStyle) {
		let rowContainer = document.createElement("div");
		rowContainer.classList.add(KEYBOARD_KEY_ROW_CONTAINER);
		if(keys && keys.constructor === Array) {
			let numberOfKeys = keys.length;
			for(let _curKey = 0; _curKey < numberOfKeys; _curKey++) {
				let key = createKey(keys[_curKey], keyboardStyle);
				rowContainer.appendChild(key);
			}
		}
		return rowContainer;
	}

	function createKey(keyType, keyStyle) {
		let key = document.createElement("div");
		key.classList.add(keyStyle);
		key.classList.add(KEYBOARD_KEY);

		let keyMain = document.createElement("span");
		keyMain.classList.add(keyStyle);
		keyMain.classList.add(KEYBOARD_KEY);

		switch(keyType) {
			case "\\": case "1": case "2": case "3": case "4":
			case "5": case "6": case "7": case "8": case "9":
			case "0": case "'": case "«": case "+": case "´":
			case "º": case ",": case ".": case "-": case "<":
				key.classList.add(KEYBOARD_KEY_NUMERIC);
				keyMain.textContent = keyType;
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				keyPressHandler(key, keyType);
				createSecondaryKey(key, keyType, keyStyle);
				break;
			case "~":
				key.classList.add(KEYBOARD_KEY_NUMERIC);
				keyMain.textContent = keyType;
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				tildePressHandler(key, keyType);
				createSecondaryKey(key, keyType, keyStyle);
				break;
			case "a": case "b": case "c": case "d": case "e":
			case "f": case "g": case "h": case "i": case "j":
			case "k": case "l": case "m": case "n": case "o":
			case "p": case "q": case "r": case "s": case "t":
			case "u": case "v": case "w": case "x": case "y": 
			case "z": case "ç":
				keyMain.textContent = keyType;
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_PRIMARY);
				keyPressHandler(key, keyType);
				break;
			case "tab":
				keyMain.textContent = "Tab";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_TAB);
				break;
			case "caps":
				keyMain.textContent = "Maiúsculas";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_CAPS);
				capsPressHandler(key);
				break;
			case "backspace":
				keyMain.textContent = "keyboard_backspace";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_BACKSPACE);
				backspacePressHandler(key);
				break;
			case "left_shift":
				keyMain.textContent = "Shift";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_LEFT_SHIFT);
				shiftPressHandler(key);
				break;
			case "right_shift":
				keyMain.textContent = "Shift";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_RIGHT_SHIFT);
				shiftPressHandler(key);
				break;
			case "enter":
				keyMain.textContent = "Enter";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_ENTER);
				break;
			case "up_arrow":
				keyMain.textContent = "keyboard_arrow_up";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_ARROW);
				break;
			case "down_arrow":
				keyMain.textContent = "keyboard_arrow_down";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_ARROW);
				break;
			case "left_arrow":
				keyMain.textContent = "keyboard_arrow_left";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_ARROW);
				break;
			case "right_arrow":
				keyMain.textContent = "keyboard_arrow_right";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_ARROW);
				break;
			case "delete":
				keyMain.textContent = "Del";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				// key.classList.add(KEYBOARD_KEY_RIGHT_SHIFT);
				break;
			case "spacebar":
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_SPACEBAR);
				keyPressHandler(key, keyType);
				break;
		}

		key.appendChild(keyMain);
		return key;
	}

	function createSecondaryKey(key, keyType, keyStyle) {
		let keySecondary = document.createElement("span");
		keySecondary.classList.add(keyStyle);
		keySecondary.classList.add(KEYBOARD_KEY);
		keySecondary.classList.add(KEYBOARD_KEY_SECONDARY);

		switch(keyType) {
			case "\\": 
				keySecondary.textContent = "|";
				break;
			case "1": 
				keySecondary.textContent = "!";
				break;
			case "2":
				keySecondary.textContent = "\"";
				break; 
			case "3": 
				keySecondary.textContent = "#";
				break;
			case "4":
				keySecondary.textContent = "$";
				break;
			case "5":
				keySecondary.textContent = "%";
				break; 
			case "6":
				keySecondary.textContent = "&";
				break;
			case "7":
				keySecondary.textContent = "/";
				break;
			case "8":
				keySecondary.textContent = "(";
				break; 
			case "9":
				keySecondary.textContent = ")";
				break;
			case "0":
				keySecondary.textContent = "=";
				break;
			case "'":
				keySecondary.textContent = "?";
				break;
			case "«":
				keySecondary.textContent = "»";
				break;
			case "+": 
				keySecondary.textContent = "*";
				break;
			case "´":
				keySecondary.textContent = "`";
				break;
			case "º":
				keySecondary.textContent = "ª";
				break;
			case "~":
				keySecondary.textContent = "^";
				break;
			case ",":
				keySecondary.textContent = ";";
				break;
			case ".":
				keySecondary.textContent = ":";
				break;
			case "-":
				keySecondary.textContent = "_";
				break;
			case "<":
				keySecondary.textContent = ">";
				break;
		}

		key.appendChild(keySecondary);
	}

	function keyPressHandler(key, keyType) {
		key.addEventListener("mousedown", function(evt) {
			evt.preventDefault();
			let element = document.activeElement;
			if(element && element.tagName && element.tagName.toLowerCase() === "input") {
				let startPos = element.selectionStart;
				let endPos = element.selectionEnd;
				let currentText = element.value;
				let char = keyType;

				if(keyType === "spacebar") {
					char = " ";
				}

				if(shiftActive) {
					if(key.classList.contains(KEYBOARD_KEY_NUMERIC)) {
						char = key.querySelector("." + KEYBOARD_KEY_SECONDARY).textContent;
					}
				}

				if(printTilde) {
					if(keyType === "a") {
						char = "ã";
					} else if(keyType === "o") {
						char = "õ";
					} else if(keyType === "n") {
						char = "ñ";
					} else {
						char = "~" + keyType;
					}
					printTilde = false;
				}

				if(printPower) {
					if(keyType === "a") {
						char = "â";
					} else if(keyType === "e") {
						char = "ê";
					} else if(keyType === "i") {
						char = "î";
					} else if(keyType === "o") {
						char = "ô";
					} else if(keyType === "u") {
						char = "û";
					} else {
						char = "^" + keyType;
					}
					printPower = false;
				}

				if((capsActive && !shiftActive) || (!capsActive && shiftActive)) {
					char = char.toUpperCase();
				}			

				element.value = currentText.substr(0, startPos) + char + currentText.substr(endPos);
				element.setSelectionRange(startPos + char.length, startPos + char.length);
			}
		});
	}

	function capsPressHandler(key) {
		key.addEventListener("mousedown", function(evt) {
			evt.preventDefault();
			let keys = document.querySelectorAll("." + KEYBOARD_KEY_PRIMARY);
			let numberOfKeys = keys.length;
			if(keys && numberOfKeys) {
				for(let _curKey = 0; _curKey < numberOfKeys; _curKey++) {
					if(!capsActive) {
						if(!shiftActive) {
							keys[_curKey].textContent = keys[_curKey].textContent.toUpperCase();
						} else {
							keys[_curKey].textContent = keys[_curKey].textContent.toLowerCase();
						}
					} else {
						if(!shiftActive) {
							keys[_curKey].textContent = keys[_curKey].textContent.toLowerCase();
						} else {
							keys[_curKey].textContent = keys[_curKey].textContent.toUpperCase();
						}
					}
				}
			}

			if(!capsActive) {
				capsActive = true;
				key.classList.add(ACTIVE);
			} else {
				capsActive = false;
				key.classList.remove(ACTIVE);
			}
		});
	}

	function shiftPressHandler(key) {
		key.addEventListener("mousedown", function(evt) {
			evt.preventDefault();
			let keys = document.querySelectorAll("." + KEYBOARD_KEY_SECONDARY);
			let numberOfKeys = keys.length;
			if(keys && numberOfKeys) {
				for(let _curKey = 0; _curKey < numberOfKeys; _curKey++) {
					if(!shiftActive) {
						keys[_curKey].classList.add(ACTIVE);
					} else {
						keys[_curKey].classList.remove(ACTIVE);
					}
				}
			}

			let letterKeys = document.querySelectorAll("." + KEYBOARD_KEY_PRIMARY);
			let numberOfLetterKeys = letterKeys.length;
			if(letterKeys && numberOfLetterKeys) {
				for(let _curKey = 0; _curKey < numberOfLetterKeys; _curKey++) {
					if(!shiftActive) {
						if(!capsActive) {
							letterKeys[_curKey].textContent = letterKeys[_curKey].textContent.toUpperCase();
						} else {
							letterKeys[_curKey].textContent = letterKeys[_curKey].textContent.toLowerCase();
						}
					} else {
						if(!capsActive) {
							letterKeys[_curKey].textContent = letterKeys[_curKey].textContent.toLowerCase();
						} else {
							letterKeys[_curKey].textContent = letterKeys[_curKey].textContent.toUpperCase();
						}
					}
				}
			}

			let left_shift = CURRENT_KEYBOARD.querySelector("." + KEYBOARD_KEY_LEFT_SHIFT);
			let right_shift = CURRENT_KEYBOARD.querySelector("." + KEYBOARD_KEY_RIGHT_SHIFT);

			if(!shiftActive) {
				shiftActive = true;
				if(left_shift) {
					left_shift.classList.add(ACTIVE);
				}
				if(right_shift) {
					right_shift.classList.add(ACTIVE);
				}
			} else {
				shiftActive = false;
				if(left_shift) {
					left_shift.classList.remove(ACTIVE);
				}
				if(right_shift) {
					right_shift.classList.remove(ACTIVE);
				}
			}
		});
	}

	function tildePressHandler(key) {
		key.addEventListener("mousedown", function(evt) {
			evt.preventDefault();
			if(printTilde) {
				let element = document.activeElement;
				if(element && element.tagName && element.tagName.toLowerCase() === "input") {
					let startPos = element.selectionStart;
					let endPos = element.selectionEnd;
					let currentText = element.value;
					let char = null;
					if(shiftActive) {
						char = "~^";
					} else {
						char = "~~";
					}
					element.value = currentText.substr(0, startPos) + char + currentText.substr(endPos);
					element.setSelectionRange(startPos + char.length, startPos + char.length);
				}
				printTilde = false;
				printPower = false;
				return;
			}

			if(printPower) {
				let element = document.activeElement;
				if(element && element.tagName && element.tagName.toLowerCase() === "input") {
					let startPos = element.selectionStart;
					let endPos = element.selectionEnd;
					let currentText = element.value;
					let char = null;
					if(shiftActive) {
						char = "^^";
					} else {
						char = "^~";
					}
					element.value = currentText.substr(0, startPos) + char + currentText.substr(endPos);
					element.setSelectionRange(startPos + char.length, startPos + char.length);
				}
				printTilde = false;
				printPower = false;
				return;
			}

			if(shiftActive) {
				printPower = true;
				printTilde = false;
			} else {
				printPower = false;
				printTilde = true;
			}
		});
	}

	function backspacePressHandler(key) {
		key.addEventListener("mousedown", function(evt) {
			evt.preventDefault();
			let element = document.activeElement;
			if(element && element.tagName && element.tagName.toLowerCase() === "input") {
				let startPos = element.selectionStart;
				let endPos = element.selectionEnd;
				let currentText = element.value;
				let startOffset = startPos ? (startPos - 1) : startPos;
				let charRemoved = (startPos === endPos) ? 1 : (endPos - startPos);
				if(startPos !== endPos) {
					element.value = currentText.substr(0, startOffset + 1) + currentText.substr(startOffset + charRemoved + 1);
					element.setSelectionRange(endPos - charRemoved, endPos - charRemoved);
				} else {
					element.value = currentText.substr(0, startOffset) + currentText.substr(endPos);
					element.setSelectionRange(startOffset, startOffset);
				}
				printTilde = false;
			}
		});
	}

	function resetKeyboard() {
		printTilde = false;
		capsActive = false;
		shiftActive = false;

		let keys = document.querySelectorAll("." + KEYBOARD_KEY_PRIMARY);
		let numberOfKeys = keys.length;
		if(keys && numberOfKeys) {
			for(let _curKey = 0; _curKey < numberOfKeys; _curKey++) {
				keys[_curKey].textContent = keys[_curKey].textContent.toLowerCase();
			}
		}

		let caps = document.querySelector("." + KEYBOARD_KEY_CAPS);
		caps.classList.remove(ACTIVE);

		let left_shift = document.querySelector("." + KEYBOARD_KEY_LEFT_SHIFT);
		left_shift.classList.remove(ACTIVE);

		let right_shift = document.querySelector("." + KEYBOARD_KEY_RIGHT_SHIFT);
		right_shift.classList.remove(ACTIVE);
	}

	function VirtualKeyboard() {
		createKeyboard_v1();
		window.addEventListener("click", function(evt) {
			if(document.activeElement.tagName && document.activeElement.tagName.toLowerCase() === "input") {
				CURRENT_KEYBOARD.classList.add(VISIBLE);
			} else {
				CURRENT_KEYBOARD.classList.remove(VISIBLE);
				resetKeyboard();
			}
		});

	}
	VirtualKeyboard.prototype = Object.create(this.constructor.prototype);
	VirtualKeyboard.prototype.constructor = VirtualKeyboard;

	VirtualKeyboard.prototype.setTarget = function(target) {
		/*
			target = {
				type: "input",
				onEnterCallback: function() {},
				onTabCallback: function() {},
				onUpArrowCallback: function() {},
				onDownArrowCallback: function() {},
			}

			OR

			target = [target];
		*/
		if(target) {
			if(target.constructor === Array) {

			} else if(target.constructor === Object) {

			} else {
				// error
			}
		} else {
			// error: empty target
		}
		


	}

	return new VirtualKeyboard();
}