function VirtualKeyboard() {
	let KEYBOARD_STYLE_V1 = "lff--keyboard_v1";

	let KEYBOARD_CONTAINER = "lff--keyboard_container";
	let KEYBOARD_VISIBLE = "lff--keyboard_visible";
	let KEYBOARD_KEY_ROW_CONTAINER = "lff--keyboard_key_row_container";
	let KEYBOARD_KEY = "lff--keyboard_key";
	let KEYBOARD_KEY_NUMERIC = "lff--keyboard_key_numeric";
	let KEYBOARD_KEY_LETTER = "lff--keyboard_key_letter";
	let KEYBOARD_KEY_SPECIAL = "lff--keyboard_key_special";
	let KEYBOARD_KEY_TAB = "lff--keyboard_key_tab";
	let KEYBOARD_KEY_CAPS = "lff--keyboard_key_caps";
	let CURRENT_KEYBOARD = null;

	function createKeyboard_v1() {
		let container = document.createElement("div");
		container.addEventListener("mousedown", function(evt) {
			evt.preventDefault();
		});
		container.classList.add(KEYBOARD_CONTAINER);
		container.classList.add(KEYBOARD_STYLE_V1);
		createRow(container, ["\\", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "'", "«"], KEYBOARD_STYLE_V1);
		createRow(container, ["tab", "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "+", "´"], KEYBOARD_STYLE_V1);
		createRow(container, ["caps", "a", "s", "d", "f", "g", "h", "j", "k", "l", "ç", "º", "~"], KEYBOARD_STYLE_V1);
		createRow(container, ["left_shift", "z", "x", "c", "v", "b", "n", "m", ",", ".", "-", "right_shift"], KEYBOARD_STYLE_V1);
		document.body.appendChild(container);
		CURRENT_KEYBOARD = container;
	}

	function createRow(container, keys, keyboardStyle) {
		let rowContainer = document.createElement("div");
		rowContainer.classList.add(KEYBOARD_KEY_ROW_CONTAINER);
		if(keys && keys.constructor === Array) {
			let numberOfKeys = keys.length;
			for(let _curKey = 0; _curKey < numberOfKeys; _curKey++) {
				createKey(rowContainer, keys[_curKey], keyboardStyle);
			}
		}
		container.appendChild(rowContainer);
	}

	function createKey(container, keyType, keyStyle) {
		let key = document.createElement("div");
		key.classList.add(keyStyle);
		key.classList.add(KEYBOARD_KEY);

		let keyMain = document.createElement("span");
		keyMain.classList.add(keyStyle);
		keyMain.classList.add(KEYBOARD_KEY);
		key.appendChild(keyMain);

		switch(keyType) {
			case "\\": case "1": case "2": case "3": case "4":
			case "5": case "6": case "7": case "8": case "9":
			case "0": case "'": case "«": case "+": case "´":
			case "º": case "~": case ",": case ".": case "-":
				keyMain.textContent = keyType;
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				keypressHandler(key, keyType);
				break;
			case "a": case "b": case "c": case "d": case "e":
			case "f": case "g": case "h": case "i": case "j":
			case "k": case "l": case "m": case "n": case "o":
			case "p": case "q": case "r": case "s": case "t":
			case "u": case "v": case "w": case "x": case "y": 
			case "z": case "ç":
				keyMain.textContent = keyType;
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keypressHandler(key, keyType);
				break;
			case "tab":
				keyMain.textContent = "Tab";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_TAB);
				break;
			case "caps":
				keyMain.textContent = "Maiúsculas";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_CAPS);
				break;
		}

		container.appendChild(key);
	}

	function keypressHandler(key, keyType) {
		key.addEventListener("mousedown", function(evt) {
			evt.preventDefault();
			let element = document.activeElement;
			if(element && element.tagName && element.tagName.toLowerCase() === "input") {
				let startPos = element.selectionStart;
				let endPos = element.selectionEnd;
				let currentText = element.value;
				element.value = currentText.substr(0, startPos) + keyType + currentText.substr(endPos);
				element.setSelectionRange(startPos + 1, startPos + 1);
			}
		});
	}

	function VirtualKeyboard() {
		createKeyboard_v1();
		window.addEventListener("click", function(evt) {
			if(document.activeElement.tagName && document.activeElement.tagName.toLowerCase() === "input") {
				CURRENT_KEYBOARD.classList.add(KEYBOARD_VISIBLE);
			} else {
				CURRENT_KEYBOARD.classList.remove(KEYBOARD_VISIBLE);
			}
		});

	}
	VirtualKeyboard.prototype = Object.create(this.constructor.prototype);
	VirtualKeyboard.prototype.constructor = VirtualKeyboard;

	VirtualKeyboard.prototype.setTarget = function(targetArray) {
		/*
			targetArray = ["input", "contentEditable"]
			targetArray = ["all"];
		*/
	}

	return new VirtualKeyboard();
}