(function () {
	if ( typeof window.CustomEvent === "function" ) return false;

	function CustomEvent ( event, params ) {
		params = params || { bubbles: false, cancelable: false, detail: undefined };
		let evt = document.createEvent( 'CustomEvent' );
		evt.initCustomEvent( event, params.bubbles, params.cancelable, params.detail );
		return evt;
	}

	CustomEvent.prototype = window.Event.prototype;
	window.CustomEvent = CustomEvent;
})();


(function() {
	"use strict";

	let BACKGROUND_GENERIC = "lff--background";
	let BACKGROUND_001 = "lff--background_001";
	let INPUT = "lff--input";
	let INPUT_LABEL = "lff--input_label";
	let INPUT_CONTAINER = "lff--input_container";
	let INPUT_UNDERLINE = "lff--input_underline";
	let INPUT_LIGHTBEAM = "lff--input_lightbeam";
	let INPUT_WRAPPER = "lff--input_wrapper";
	let MAIN_CONTENT = "lff--main";
	let SVG_GENERIC = "lff--svg";
	let SVG_FINGERPRINT = "lff--icon_fingerprint";



	let DOCUMENT_OBSERVER_OBSERVED_ELEMENTS = [];
	let DOCUMENT_OBSERVER_TARGET = document;
	let DOCUMENT_OBSERVER_CONFIGURATION = {
		attributes: true,
		childList: true, 
		subtree: true,
	};
	let DOCUMENT_OBSERVER = new MutationObserver(function(mutations) {
		let numberOfMutations = mutations.length;
		for(let _curMutation = 0; _curMutation < numberOfMutations; _curMutation++) {
			let mutation = mutations[_curMutation];
			if(mutation.type === "childList") {
				let elementsAdded = mutation.addedNodes;
				if(elementsAdded) {
					let numberOfElementsAdded = elementsAdded.length;
					if(numberOfElementsAdded) {
						for(let _curElAdded = 0; _curElAdded < numberOfElementsAdded; _curElAdded++) {
							if(mutation.addedNodes[_curElAdded].tagName) {
								let numberOfObservedElements = DOCUMENT_OBSERVER_OBSERVED_ELEMENTS.length;
								for(let _curObservedEl = 0; _curObservedEl < numberOfObservedElements; _curObservedEl++) {
									let currentEl = DOCUMENT_OBSERVER_OBSERVED_ELEMENTS[_curObservedEl];
									let foundElements = mutation.addedNodes[_curElAdded].querySelectorAll("." + currentEl.target);
									let numberOfElementsFound = foundElements.length;
									if(foundElements && numberOfElementsFound) {
										for(let _curFoundEl = 0; _curFoundEl < numberOfElementsFound; _curFoundEl++) {
											if(currentEl.onCreationCallback) {
												this.disconnect();
												currentEl.onCreationCallback.call(foundElements[_curFoundEl]);
												this.observe(DOCUMENT_OBSERVER_TARGET, DOCUMENT_OBSERVER_CONFIGURATION);
											}
										}
									}
								}
							}
						}
					}
				}
			} else if(mutation.type === "attributes") {
				let numberOfObservedElements = DOCUMENT_OBSERVER_OBSERVED_ELEMENTS.length;
				for(let _curObservedEl = 0; _curObservedEl < numberOfObservedElements; _curObservedEl++) {
					let currentEl = DOCUMENT_OBSERVER_OBSERVED_ELEMENTS[_curObservedEl];
					if(hasClass(mutation.target, currentEl.target)) {
						if(currentEl.onAttributeChangeCallback) {
							this.disconnect();
							currentEl.onAttributeChangeCallback.call(mutation.target);
							this.observe(DOCUMENT_OBSERVER_TARGET, DOCUMENT_OBSERVER_CONFIGURATION);
						}
						
					}
				}
			}
		}
	});
	DOCUMENT_OBSERVER.observe(DOCUMENT_OBSERVER_TARGET, DOCUMENT_OBSERVER_CONFIGURATION);

	function hasClass(element, classNm) {
		return (' ' + element.className + ' ').indexOf(' ' + classNm + ' ') > -1;
	}

	// document.addEventListener("DOMContentLoaded", function(evt) {
		// setTimeout(function() {
			setElementCreationCallback(BACKGROUND_001, updateBackground_001);
			setElementCreationCallback(SVG_FINGERPRINT, updateFingerprintIcon);
			setElementCreationCallback(MAIN_CONTENT, updateMainContent, updateMainContent);
			setElementCreationCallback(INPUT, updateInput);
		// }, 100);
	// });

	function updateMainContent() {
		let main = this;
		let mainSrc = main.dataset.currentLocation ? main.dataset.currentLocation + main.dataset.src : main.dataset.src;
		main.dataset.currentLocation = mainSrc.match(/.*\//g);
		if(mainSrc) {
			loadPage.call(main, mainSrc, replaceAnchors);
		}
	}

	function loadPage(source, callback) {
		let request = new XMLHttpRequest();
		let loadSrcHandlerCallback = loadSrcHandler.bind(request, this, callback);
		request.addEventListener("load", loadSrcHandlerCallback);
		request.open("GET", source);
		request.send();
	}

	function loadSrcHandler(container, callback) {
		parseStyleElements(this.responseText);
		container.innerHTML = cleanStylesAndScripts(this.responseText);
		parseScriptElements(this.responseText);

		if(callback) {
			callback.call(container);
		}
	}

	function parseStyleElements(content) {
		let styleElementOpenTagRegex = /<style.*>/g;
		let styleElementCloseTagRegex = /<\/style>/g;
		let openStyleTag = null;
		while(openStyleTag = styleElementOpenTagRegex.exec(content)) {
			let closeStyleTag = styleElementCloseTagRegex.exec(content);
			let newStyle = document.createElement("style");
			newStyle.innerHTML = content.substring(openStyleTag.index + openStyleTag[0].length, closeStyleTag.index);
			document.head.appendChild(newStyle);
			// 	Need to add random class name... so that i can remove it on another page load...
		}
	}

	function parseScriptElements(content) {
		let scriptElementOpenTagRegex = /<script.*>/g;
		let scriptElementCloseTagRegex = /<\/script>/g;
		let openScriptTag = null;
		while(openScriptTag = scriptElementOpenTagRegex.exec(content)) {
			let closeScriptTag = scriptElementCloseTagRegex.exec(content);
			let newScript = document.createElement("script");
			newScript.innerHTML = content.substring(openScriptTag.index + openScriptTag[0].length, closeScriptTag.index);
			document.body.appendChild(newScript);
		}
	}

	function cleanStylesAndScripts(content) {
		let styleRegex = /<style(.|[\r\n])*<\/style>/g;
		let scriptRegex = /<script(.|[\r\n])*<\/script>/g;
		let parsedContent = content;
		while(parsedContent.match(styleRegex)) {
			parsedContent = parsedContent.replace(styleRegex, "");
		}
		while(parsedContent.match(scriptRegex)) {
			parsedContent = parsedContent.replace(scriptRegex, "");
		}
		return parsedContent;
	}

	function replaceAnchors() {
		let anchors = this.getElementsByTagName("a");
		let numberOfAnchors = anchors.length;
		if(anchors && numberOfAnchors) {
			for(let _curAnchor = 0; _curAnchor < numberOfAnchors; _curAnchor++) {
				if(anchors[_curAnchor].target && anchors[_curAnchor].target.toLowerCase() === "_blank") {
					continue;
					// should add http://...
				} else {
					anchors[_curAnchor].addEventListener("click", function(evt) {
						evt.preventDefault();
						// alert("heita");
					});
				}
			}
		}
	}

	function setElementCreationCallback(elementClass, creationCallback, attributeChangeCallback) {
		DOCUMENT_OBSERVER_OBSERVED_ELEMENTS.push({
			target: elementClass,
			onCreationCallback: creationCallback,
			onAttributeChangeCallback: attributeChangeCallback,
		});
	}

	function updateInput() {
		let wrapper = document.createElement("div");
		wrapper.classList.add(INPUT_WRAPPER);

		let container = document.createElement("div");
		container.classList.add(INPUT_CONTAINER);
		wrapper.appendChild(container);

		let label = document.createElement("span");
		label.textContent = this.value;
		this.value = "";
		label.classList.add(INPUT_LABEL);
		container.appendChild(label);

		let underline = document.createElement("div");
		underline.classList.add(INPUT_UNDERLINE);
		wrapper.appendChild(underline);

		let lightbeam = document.createElement("div");
		lightbeam.classList.add(INPUT_LIGHTBEAM);
		wrapper.appendChild(lightbeam);

		this.parentElement.insertBefore(wrapper, this);
		container.appendChild(this);
		container.appendChild(label);

		let inputWidth = this.getBoundingClientRect().width;
		lightbeam.style.transformOrigin = (inputWidth/2) + "px center 0px";

		function updateWrapper() {
			if(this.value === "") {
				wrapper.classList.remove("hasText");
			}
		}

		this.addEventListener("focus", function(evt) {
			wrapper.classList.add("hasText");
			wrapper.classList.add("focus");
		});

		this.addEventListener("blur", function(evt) {
			wrapper.classList.remove("focus");
			updateWrapper.call(this);
		});

		this.addEventListener("change", function(evt) {
			updateWrapper.call(this);
		});

	}

	function updateBackground_001() {
		this.classList.add(BACKGROUND_GENERIC);
		this.innerHTML = "<svg xmlns=\"http://www.w3.org/2000/svg\" " +
			"viewBox=\"0 0 1440 810\" preserveAspectRatio=\"xMinYMin slice\" aria-hidden=\"true\"><path " + 
			"fill=\"#efefee\" d=\"M592.66 0c-15 64.092-30.7 125.285-46.598 183.777C634.056 325.56 748.348 " + 
			"550.932 819.642 809.5h419.672C1184.518 593.727 1083.124 290.064 902.637 0H592.66z\"/><path " + 
			"fill=\"#f6f6f6\" d=\"M545.962 183.777c-53.796 196.576-111.592 361.156-163.49 490.74 11.7 " + 
			"44.494 22.8 89.49 33.1 134.883h404.07c-71.294-258.468-185.586-483.84-273.68-625.623z\"/><path " +
			"fill=\"#f7f7f7\" d=\"M153.89 0c74.094 180.678 161.088 417.448 228.483 674.517C449.67 506.337 " +
			"527.063 279.465 592.56 0H153.89z\"/><path fill=\"#fbfbfc\" d=\"M153.89 0H0v809.5h415.57C345.477 " +
			"500.938 240.884 211.874 153.89 0z\"/><path fill=\"#ebebec\" d=\"M1144.22 501.538c52.596-134.583 " +
			"101.492-290.964 134.09-463.343 1.2-6.1 2.3-12.298 3.4-18.497 0-.2.1-.4.1-.6 1.1-6.3 2.3-12.7 " +
			"3.4-19.098H902.536c105.293 169.28 183.688 343.158 241.684 501.638v-.1z\"/><path fill=\"#e1e1e1\" " +
			"d=\"M1285.31 0c-2.2 12.798-4.5 25.597-6.9 38.195C1321.507 86.39 1379.603 158.98 1440 " +
			"257.168V0h-154.69z\"/><path fill=\"#e7e7e7\" d=\"M1278.31,38.196C1245.81,209.874 1197.22,365.556 " +
			"1144.82,499.838L1144.82,503.638C1185.82,615.924 1216.41,720.211 " +
			"1239.11,809.6L1439.7,810L1439.7,256.768C1379.4,158.78 1321.41,86.288 1278.31,38.195L1278.31,38.196z" + 
			"\"/></svg>";
	}


	function updateFingerprintIcon() {
		// this.classList.add(SVG_GENERIC);
		this.innerHTML = "<svg class=\"lff--icon_fingerprint lff--svg\" id=\"fingerprint_icon\" version=\"1.1\" viewBox=\"0 0 283.46 283.46\" " + 
			"xml:space=\"preserve\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\"> " +
			"<path d=\"m 137.84375,4.2363281 c -7.63304,0.2387062 -15.34781,1.11672 -23.08008,2.6757813 C " + 
			"79.629247,13.995397 50.295416,33.887738 30.705078,60.732422 a 4.0005354,4.0005354 0 1 0 6.462891,4.716797 C " + 
			"55.627631,40.153903 83.206175,21.436572 116.34375,14.755859 145.51469,8.8741045 174.3308,13.261088 " +
			"199.11328,25.425781 a 4.0004,4.0004 0 1 0 3.52344,-7.18164 C 182.90908,8.5606606 160.74287,3.5202097 " +
			"137.84375,4.2363281 Z\"/>" + 
			"<path d=\"M 218.9375 28.453125 A 4.0004 4.0004 0 0 0 216.58203 35.759766 C 242.87277 54.208694 262.38866 " +
			"82.356673 269.24219 116.3457 A 4.0008509 4.0008509 0 0 0 269.44336 117.01562 C 271.26347 126.29598 272.05115 " +
			"135.53641 271.87695 144.61914 A 4.0007252 4.0007252 0 1 0 279.87695 144.77148 C 280.06648 134.88934 279.18905 " +
			"124.8337 277.15625 114.75 A 4.0004 4.0004 0 0 0 276.9082 113.93359 C 269.4918 78.268388 248.86174 48.638923 " +
			"221.17578 29.210938 A 4.0004 4.0004 0 0 0 218.9375 28.453125 z\"/>" + 
			"<path d=\"m 141.96484,137.94141 a 4.0004,4.0004 0 0 0 -3.85351,4.8457 c 9.41866,46.70762 -4.47747,92.64612 " +
			"-33.66211,125.86328 a 4.0004,4.0004 0 1 0 6.00976,5.2793 c 30.76936,-35.02084 45.41548,-83.52423 " +
			"35.49414,-132.72461 a 4.0004,4.0004 0 0 0 -3.98828,-3.26367 z\"/>" + 
			"<path d=\"m 119.02539,216.28906 a 4.0004,4.0004 0 0 0 -3.57617,2.59571 c -6.35944,16.29685 -15.954191,31.17496 " +
			"-28.156251,43.68554 a 4.0004,4.0004 0 1 0 5.726562,5.58594 c 12.951939,-13.27942 23.132259,-29.06414 " +
			"29.882809,-46.36328 a 4.0004,4.0004 0 0 0 -3.87695,-5.50391 z\"/>" + 
			"<path d=\"m 142.06836,121.18359 c -1.38017,-0.006 -2.77876,0.12724 -4.18164,0.41016 -11.22187,2.26336 " +
			"-18.551,13.29421 -16.28906,24.51758 l 0.46484,2.30859 c 3.15655,17.24647 2.84444,34.33757 -0.62109,50.50977 a " +
			"4.0004,4.0004 0 1 0 7.82226,1.67578 c 3.8462,-17.94858 4.15042,-36.96964 0.29492,-56.09375 l -0.24023,-1.19141 " +
			"c -0.69289,-6.53123 3.57263,-12.5575 10.14844,-13.88476 6.80446,-1.37226 13.30196,2.83848 14.9375,9.51367 l " +
			"0.10742,0.5332 c 9.82173,48.7053 -3.11564,96.65922 -31.47656,132.95117 a 4.0004,4.0004 0 1 0 6.30273,4.92579 c " +
			"29.05705,-37.18274 42.61039,-86.11299 33.62305,-135.94141 l 0.14648,-0.0469 -0.70312,-3.48828 c -1.98036,-9.81981 " +
			"-10.67475,-16.65885 -20.33594,-16.69922 z\"/>" + 
			"<path d=\"m 110.30273,152.0918 a 4.0004,4.0004 0 0 0 -3.75585,4.58984 c 5.06756,37.3918 -8.903794,73.48292 " +
			"-34.931646,97.83398 a 4.0004,4.0004 0 1 0 5.464844,5.8418 c 27.866152,-26.07093 42.816962,-64.7398 " +
			"37.394532,-104.75 a 4.0004,4.0004 0 0 0 -4.17188,-3.51562 z\"/>" + 
			"<path d=\"m 142.13477,104.4668 c -2.49069,-0.009 -5.01883,0.23113 -7.55274,0.74218 -15.1419,3.05318 " +
			"-26.3521,14.86875 -29.32812,29.13282 a 4.0004,4.0004 0 1 0 7.83203,1.63281 c 2.33798,-11.20593 11.10202,-20.50705 " +
			"23.07812,-22.92188 15.90222,-3.20725 31.26095,6.92685 34.66406,22.73633 l 0.0781,0.38672 c 2.38722,11.84215 " +
			"3.55561,23.63981 3.58789,35.26953 a 4.0004,4.0004 0 1 0 8,-0.0215 c -0.0306,-11.03639 -1.18093,-22.22299 " +
			"-3.23242,-33.43945 l 0.19531,-0.0742 -0.67187,-3.33008 c -3.57539,-17.73721 -19.21561,-30.0508 " +
			"-36.65039,-30.11328 z\"/>" +
			"<path d=\"m 177.31836,188.59375 a 4.0004,4.0004 0 0 0 -3.97461,3.60352 c -3.36369,29.49855 -13.98841,57.35003 " +
			"-30.37109,81.29101 a 4.0004,4.0004 0 1 0 6.60156,4.51953 c 17.10532,-24.99702 28.20444,-54.08484 " +
			"31.71875,-84.90429 a 4.0004,4.0004 0 0 0 -3.97461,-4.50977 z\"/>" + 
			"<path d=\"m 138.81641,87.84375 c -2.49866,0.149812 -5.01721,0.47413 -7.53711,0.982422 -29.31875,5.913096 " +
			"-48.361323,34.573308 -42.449222,63.894528 l 0.275391,1.36524 c 6.513173,34.87655 -6.56022,68.94377 " +
			"-31.658203,90.67968 a 4.0008728,4.0008728 0 1 0 5.238281,6.04883 c 27.541563,-23.85216 41.787133,-61.46573 " +
			"34.080078,-99.6914 l -0.1875,-0.9336 c -4.462759,-24.74338 11.519845,-48.52607 36.283205,-53.519528 " +
			"4.3102,-0.869416 8.59221,-1.107879 12.75781,-0.783203 a 4.0004,4.0004 0 1 0 0.62109,-7.976563 c -2.4462,-0.190662 " +
			"-4.92516,-0.216218 -7.42382,-0.06641 z\"/>" +
			"<path d=\"m 166.48438,94.074219 a 4.0004,4.0004 0 0 0 -1.99024,7.519531 c 11.27956,6.28879 19.83867,17.21695 " +
			"22.7207,30.83008 l 0.0898,0.44531 c 9.96089,49.39656 0.48457,98.1467 -23.14649,138.43164 a 4.0004,4.0004 0 1 0 " +
			"6.90039,4.04688 c 24.0605,-41.01703 33.88628,-90.54308 24.5918,-140.78125 l 0.16992,-0.0703 -0.65039,-3.21875 c " +
			"-3.25845,-16.15535 -13.41576,-29.21923 -26.7793,-36.669918 a 4.0004,4.0004 0 0 0 -1.90624,-0.533203 z\"/>" +
			"<path d=\"m 72.298828,197.94336 a 4.0004,4.0004 0 0 0 -3.570312,2.59961 c -4.978498,12.81858 -13.219044,24.21543 " +
			"-23.900391,32.96484 a 4.0004,4.0004 0 1 0 5.068359,6.18946 c 11.754653,-9.62859 20.81156,-22.1544 " +
			"26.289063,-36.25782 a 4.0004,4.0004 0 0 0 -3.886719,-5.49609 z\"/>" +
			"<path d=\"m 142.26758,71.035156 c -4.71159,-0.01535 -9.49514,0.443122 -14.29102,1.410156 -38.368806,7.737269 " +
			"-63.266578,45.210138 -55.529294,83.580078 l 0.205078,1.01953 c 1.477906,7.85593 1.822222,15.66013 1.013672,23.21875 " +
			"a 4.0004,4.0004 0 1 0 7.955078,0.85156 c 0.929765,-8.69178 0.563243,-17.67502 -1.253906,-26.6875 l -0.3125,-1.55078 " +
			"c -5.907691,-33.57262 15.896379,-65.812709 49.503902,-72.589841 34.04365,-6.864517 67.09349,15.034134 " +
			"74.08985,49.019531 l 0.0527,0.25781 c 5.26449,26.11133 5.52046,52.04771 1.43555,76.84571 a 4.0004885,4.0004885 0 1 " +
			"0 7.89453,1.30078 c 4.10085,-24.89478 3.87469,-50.91016 -1.07813,-77.08594 l 0.11915,-0.084 -0.51758,-2.56641 C " +
			"204.78459,94.40195 175.24873,71.142642 142.26758,71.035156 Z\"/>" +
			"<path d=\"m 204.38867,223.83789 a 4.0004,4.0004 0 0 0 -3.66406,3.01563 c -3.54822,13.25157 -8.35748,26.07464 " +
			"-14.31445,38.30273 a 4.0004,4.0004 0 1 0 7.1914,3.50391 c 6.17903,-12.68391 11.16783,-25.98786 14.84961,-39.73828 a " +
			"4.0004,4.0004 0 0 0 -4.0625,-5.08399 z\"/>" +
			"<path d=\"m 209.45312,88.716797 a 4.0004,4.0004 0 0 0 -3.01953,6.396484 c 6.55224,8.993019 11.31429,19.502539 " +
			"13.66211,31.140629 l 0.0176,0.0879 c 8.92034,44.32119 4.46435,88.19181 -10.57226,127.50195 a 4.0004,4.0004 0 1 0 " +
			"7.47265,2.85742 c 15.56787,-40.69899 20.17482,-86.16718 10.92774,-132.02539 l -0.28711,-1.42383 -0.10742,-0.0859 c " +
			"-2.67945,-12.17269 -7.72504,-23.261222 -14.64844,-32.763676 a 4.0004,4.0004 0 0 0 -3.44532,-1.685547 z\"/>" +
			"<path d=\"m 144.61328,54.355469 c -6.55795,-0.190908 -13.23968,0.355905 -19.9414,1.707031 -6.78351,1.367169 " +
			"-13.23034,3.486838 -19.26758,6.253906 a 4.0004,4.0004 0 1 0 3.33203,7.271485 c 5.48276,-2.512932 11.34108,-4.438763 " +
			"17.51758,-5.683594 24.41111,-4.921496 48.40765,1.865779 66.26171,16.488281 a 4.000546,4.000546 0 1 0 " +
			"5.07032,-6.189453 C 182.85748,62.140502 164.28714,54.928193 144.61328,54.355469 Z\"/>" +
			"<path d=\"m 89.236328,72.960938 a 4.0004,4.0004 0 0 0 -2.458984,0.929687 C 62.281547,93.782784 49.398718,126.28647 " +
			"56.0625,159.33008 l 0.179688,0.88867 c 4.410276,23.60457 -4.925107,46.61599 -22.472657,60.71289 a 4.0004,4.0004 0 1 " +
			"0 5.009766,6.23633 c 20.03195,-16.09275 30.612126,-42.54227 25.1875,-69.43359 L 63.787109,156.8418 C " +
			"58.135515,127.06864 69.790978,97.990796 91.820312,80.101562 a 4.0004,4.0004 0 0 0 -2.583984,-7.140624 z\"/>" +
			"<path d=\"m 41.857422,141.92383 a 4.0004,4.0004 0 0 0 -4.169922,4.21679 c 0.223546,5.45868 0.878211,10.97102 " + 
			"1.992188,16.49415 l 0.148437,0.74023 c 3.12125,16.89402 -3.318085,33.35191 -15.583984,43.74609 a 4.0004,4.0004 0 1 " +
			"0 5.171875,6.10352 c 14.603001,-12.37466 22.200389,-32.12976 18.15625,-52.18555 L 47.3125,159.74609 c " +
			"-0.875596,-4.66786 -1.444,-9.32306 -1.632812,-13.93359 a 4.0004,4.0004 0 0 0 -3.822266,-3.88867 z\"/>" +
			"<path d=\"m 142.39648,37.605469 c -6.93273,-0.02181 -13.96923,0.651193 -21.02734,2.074219 -43.393351,8.75036 " +
			"-75.08113,43.281844 -82.238281,84.464842 a 4.0004151,4.0004151 0 1 0 7.882813,1.36914 C 53.618521,87.508671 " +
			"82.814523,55.615124 122.95117,47.521484 175.17827,36.991689 225.94578,70.722007 236.47656,122.95117 l " +
			"0.14649,0.72461 c 0.79865,4.02691 1.51327,8.05163 2.10937,12.06836 a 4.0004626,4.0004626 0 1 0 7.91406,-1.17578 " +
			"c -0.6521,-4.39408 -1.4202,-8.79257 -2.30664,-13.19531 l -0.61523,-3.05078 -0.18555,-0.01 C 232.41649,70.583545 " +
			"189.9012,37.754894 142.39648,37.605469 Z\"/>" +
			"<path d=\"m 244.99805,152.17383 a 4.0004,4.0004 0 0 0 -4.07617,4.30664 c 1.70535,27.02689 -1.08766,53.55378 " +
			"-7.80469,78.74805 a 4.0004,4.0004 0 1 0 7.73047,2.06054 c 6.93497,-26.01173 9.81923,-53.40939 8.05859,-81.3125 " +
			"a 4.0004,4.0004 0 0 0 -3.9082,-3.80273 z\"/>" +
			"<path d=\"m 138.35938,20.943359 c -6.71155,0.209714 -13.49556,0.982665 -20.29297,2.353516 C 52.551542,36.506932 " +
			"10.082819,100.42309 23.292969,165.9375 l 0.06445,0.32227 c 1.823681,9.59801 -1.173571,18.96383 -7.34961,25.62695 " +
			"a 4.0004,4.0004 0 1 0 5.867188,5.4375 c 7.928009,-8.55326 11.778994,-20.69355 9.300781,-32.97852 l -0.15625,-0.77734 " +
			"C 19.160329,102.56972 58.633403,43.440424 119.64844,31.138672 c 12.71516,-2.564297 25.34521,-2.886607 37.5039,-1.244141 " +
			"a 4.0004,4.0004 0 1 0 1.07032,-7.927734 C 151.71,21.08703 145.07092,20.733646 138.35938,20.943359 Z\"/>" +
			"<path d=\"m 177.69727,26.427734 a 4.0004,4.0004 0 0 0 -1.26563,7.826172 c 37.75998,12.106024 68.02724,43.723495 " +
			"76.42969,85.394534 l 0.16211,0.80078 c 5.64209,28.42702 6.50604,56.68512 3.11133,83.95312 a 4.0004,4.0004 0 1 0 " +
			"7.93945,0.98828 c 3.53126,-28.36478 2.62114,-57.77451 -3.33789,-87.32617 l -0.6875,-3.41211 -0.1543,0.01 C " +
			"249.97298,71.804183 218.26523,39.263457 178.875,26.634766 a 4.0004,4.0004 0 0 0 -1.17773,-0.207032 z\"/>" +
			"<path d=\"m 22.712891,77.039062 c -1.460143,0.06154 -2.770528,0.91441 -3.417969,2.22461 C 5.1560179,107.27156 " +
			"-0.22711976,140.33845 8.298828,175.10547 c 1.2378811,5.24332 9.110062,3.3015 7.767578,-1.91602 -7.8136445,-28.6541 " +
			"-4.019083,-63.03409 10.34961,-90.279298 1.448026,-2.730448 -0.615231,-6.001623 -3.703125,-5.87109 z\"/>" + 
			"</svg>";
	}
})();





















function VirtualKeyboard() {
	let KEYBOARD_CONTAINER_V1 = "lff--keyboard_container_v1";
	let KEYBOARD_VISIBLE = "lff--keyboard_visible";
	let KEYBOARD_KEY_ROW_CONTAINER = "lff--keyboard_key_row_container";
	let KEYBOARD_KEY_V1 = "lff--keyboard_key_v1";
	let KEYBOARD_KEY_NUMERIC = "lff--keyboard_key_numeric";
	let KEYBOARD_KEY_LETTER = "lff--keyboard_key_letter";
	let KEYBOARD_KEY_SPECIAL = "lff--keyboard_key_special";
	let KEYBOARD_KEY_TAB = "lff--keyboard_key_tab";
	let CURRENT_KEYBOARD = null;

	function createKeyboard_v1() {
		let container = document.createElement("div");
		container.classList.add(KEYBOARD_CONTAINER_V1);
		createNumericRow(container);
		createQWERTYRow(container);
		document.body.appendChild(container);
		CURRENT_KEYBOARD = container;
	}

	function createNumericRow(container) {
		let rowContainer = document.createElement("div");
		rowContainer.classList.add(KEYBOARD_KEY_ROW_CONTAINER);
		createKey(rowContainer, "\\", KEYBOARD_KEY_V1);
		createKey(rowContainer, "1", KEYBOARD_KEY_V1);
		createKey(rowContainer, "2", KEYBOARD_KEY_V1);
		createKey(rowContainer, "3", KEYBOARD_KEY_V1);
		createKey(rowContainer, "4", KEYBOARD_KEY_V1);
		createKey(rowContainer, "5", KEYBOARD_KEY_V1);
		createKey(rowContainer, "6", KEYBOARD_KEY_V1);
		createKey(rowContainer, "7", KEYBOARD_KEY_V1);
		createKey(rowContainer, "8", KEYBOARD_KEY_V1);
		createKey(rowContainer, "9", KEYBOARD_KEY_V1);
		createKey(rowContainer, "0", KEYBOARD_KEY_V1);
		createKey(rowContainer, "'", KEYBOARD_KEY_V1);
		createKey(rowContainer, "«", KEYBOARD_KEY_V1);
		container.appendChild(rowContainer);
	}

	function createQWERTYRow(container) {
		let rowContainer = document.createElement("div");
		rowContainer.classList.add(KEYBOARD_KEY_ROW_CONTAINER);
		createKey(rowContainer, "tab", KEYBOARD_KEY_V1);
		createKey(rowContainer, "q", KEYBOARD_KEY_V1);
		createKey(rowContainer, "w", KEYBOARD_KEY_V1);
		createKey(rowContainer, "e", KEYBOARD_KEY_V1);
		createKey(rowContainer, "r", KEYBOARD_KEY_V1);
		createKey(rowContainer, "t", KEYBOARD_KEY_V1);
		createKey(rowContainer, "y", KEYBOARD_KEY_V1);
		createKey(rowContainer, "u", KEYBOARD_KEY_V1);
		createKey(rowContainer, "i", KEYBOARD_KEY_V1);
		createKey(rowContainer, "o", KEYBOARD_KEY_V1);
		createKey(rowContainer, "p", KEYBOARD_KEY_V1);
		createKey(rowContainer, "+", KEYBOARD_KEY_V1);
		createKey(rowContainer, "´", KEYBOARD_KEY_V1);
		container.appendChild(rowContainer);
	}

	function createKey(container, keyType, keyStyle) {
		let key = document.createElement("div");
		key.classList.add(keyStyle);

		let keyMain = document.createElement("span");
		keyMain.classList.add(keyStyle);
		key.appendChild(keyMain);

		switch(keyType) {
			case "\\": 
				keyMain.textContent = "\\";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "1":
				keyMain.textContent = "1";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "2":
				keyMain.textContent = "2";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "3":
				keyMain.textContent = "3";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "4":
				keyMain.textContent = "4";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "5":
				keyMain.textContent = "5";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "6":
				keyMain.textContent = "6";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "7":
				keyMain.textContent = "7";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "8":
				keyMain.textContent = "8";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "9":
				keyMain.textContent = "9";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "0":
				keyMain.textContent = "0";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "'":
				keyMain.textContent = "'";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "«":
				keyMain.textContent = "«";
				keyMain.classList.add(KEYBOARD_KEY_NUMERIC);
				break;
			case "tab":
				keyMain.textContent = "Tab";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				keyMain.classList.add(KEYBOARD_KEY_SPECIAL);
				key.classList.add(KEYBOARD_KEY_TAB);
				break;
			case "q":
				keyMain.textContent = "q";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				break;
			case "w":
				keyMain.textContent = "w";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				break;
			case "e":
				keyMain.textContent = "e";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				break;
			case "r":
				keyMain.textContent = "r";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				break;
			case "t":
				keyMain.textContent = "t";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				break;
			case "y":
				keyMain.textContent = "y";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				break;
			case "u":
				keyMain.textContent = "u";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				break;
			case "i":
				keyMain.textContent = "i";
				keyMain.classList.add(KEYBOARD_KEY_LETTER);
				break;
		}

		container.appendChild(key);
	}

	function VirtualKeyboard() {
		createKeyboard_v1();
		window.addEventListener("click", function(evt) {
			if(document.activeElement.tagName && document.activeElement.tagName.toLowerCase() === "input") {
				CURRENT_KEYBOARD.classList.add(KEYBOARD_VISIBLE);
			} else {
				CURRENT_KEYBOARD.classList.remove(KEYBOARD_VISIBLE);
			}
		});

	}
	VirtualKeyboard.prototype = Object.create(this.constructor.prototype);
	VirtualKeyboard.prototype.constructor = VirtualKeyboard;

	VirtualKeyboard.prototype.setTarget = function(targetArray) {
		/*
			targetArray = ["input", "contentEditable"]
			targetArray = ["all"];
		*/
	}

	return new VirtualKeyboard();
}