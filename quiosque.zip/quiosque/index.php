<?php 
	session_start();
	$_SESSION["leo"] = "grande";
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="resources/css/ShopFloorUI.css">
	<link rel="stylesheet" type="text/css" href="resources/css/VirtualKeyboard.css">
	<script type="text/javascript" src="resources/js/ShopFloorUI.js"></script>
	<script type="text/javascript" src="resources/js/VirtualKeyboard.js"></script>
</head>
<body>
	<div class="lff--background_001"></div>

	<div class="language_header">
		<span class="flag_icon_container_helper"></span>
		<span class="flag_icon_container">
			<img class="lff--flag_icon_active lff--flag_icon" src="resources/gfx/icon_pt.svg">
			<img class="lff--flag_icon" src="resources/gfx/icon_br.svg">
			<img class="lff--flag_icon" src="resources/gfx/icon_en.svg">
		</span>
	</div>

	<header class="lff--header">
		<img class="header_logo" src="resources/gfx/logo_velan.png">
	</header>

	<div class="lff--header_banner">
		<img id="header_image_1" src="resources/gfx/header_banner_01_h120.jpg">
		<img id="header_image_2" src="resources/gfx/header_banner_02_h120.jpg">
		<img id="header_image_3" src="resources/gfx/header_banner_03_h120.jpg">
		<img id="header_image_4" src="resources/gfx/header_banner_04_h120.jpg">
		<img id="header_image_5" src="resources/gfx/header_banner_05_h120.jpg">
	</div>

	<main class="lff--main" data-src="resources/html_pages/login_fingerprint.php"></main>

	<footer class="lff--footer">
		<span class="lff--footer_notice" style="margin-left: 35%">POWERED BY:</span>
		<span class="lff--footer_notice">LFFramework</span>
		<span class="lff--footer_notice" style="margin-left: 20%">CREATED BY:</span>
		<span class="lff--footer_notice">LFernandes</span>
	</footer>
</body>
</html>